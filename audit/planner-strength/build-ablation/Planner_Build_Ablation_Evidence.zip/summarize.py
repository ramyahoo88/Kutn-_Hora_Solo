"""Summarize paired Planner games, resampling the whole board with all seat rotations."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from random import Random
from statistics import mean


def read_rows(path):
    records = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
    records.sort(key=lambda item: item['start']['seed'])
    assert len({r['start']['seed'] for r in records}) == len(records), 'Repeated starting boards'
    for item in records:
        assert [r['seat'] for r in item['rows']] == list(range(item['start']['playerCount']))
    return records


def interval(deltas):
    rng = Random(20261115)
    draws = sorted(mean(rng.choices(deltas, k=len(deltas))) for _ in range(4000))
    return [draws[100], draws[3899]]


def summarize(table, base):
    rows = [seat for board in table for seat in board['rows']]
    cluster_deltas = [mean(r['results'][1]['margin'] - r['results'][0]['margin'] for r in board['rows']) for board in table]
    changes = [r for r in rows if r['firstDifference'] is not None]
    for row in rows:
        if row['firstDifference'] is None:
            a,b = row['results']
            assert a['vp'] == b['vp'] and a['coins'] == b['coins'] and a['win'] == b['win']
    phases = ('cards', 'pending', 'tax')
    matched = {p:sum(r['compared'][p] for r in rows) for p in phases}
    decisions = sum(matched.values())
    data = dict(panel=table[0]['panel'], players=table[0]['start']['playerCount'], boards=len(table), pairs=len(rows),
                different_games=len(changes), same_position_checks=matched,
                matched_cpu_ms=[sum(r['compared']['cpuUs'][i] for r in rows) / 1000 / decisions for i in (0,1)],
                build_margin_delta=mean(cluster_deltas), build_margin_95=interval(cluster_deltas),
                build_helped=sum(r['results'][1]['margin']>r['results'][0]['margin'] for r in rows),
                build_hurt=sum(r['results'][1]['margin']<r['results'][0]['margin'] for r in rows),
                new_move_kinds=Counter(r['firstDifference']['choices'][1]['kind'] for r in changes))
    data['policies'] = []
    for i, policy in enumerate(('full-turn', 'build-sequence')):
        values = [row['results'][i] for row in rows]
        data['policies'].append(dict(policy=policy, wins=sum(v['win'] for v in values), shared=sum(v['shared'] for v in values),
                                    margin=mean(v['margin'] for v in values), builds=mean(v['builds'] for v in values),
                                    stock=mean(v['plots']+v['rights'] for v in values)))
    if base:
        control = [base[record['start']['seed']] for record in table]
        assert all(a['start']==b['start'] for a,b in zip(table,control))
        values = [row['result'] for board in control for row in board['rows']]
        data['control'] = dict(wins=sum(v['win'] for v in values), shared=sum(v['shared'] for v in values),
                               margin=mean(v['margin'] for v in values))
        for i, policy in enumerate(data['policies']):
            deltas = [mean(a['results'][i]['margin']-b['result']['margin'] for a,b in zip(board['rows'],reference['rows']))
                      for board,reference in zip(table,control)]
            policy['delta_vs_control'] = mean(deltas)
            policy['delta_vs_control_95'] = interval(deltas)
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pairs', nargs='+')
    parser.add_argument('--control')
    args = parser.parse_args()
    base = {row['start']['seed']:row for row in read_rows(args.control)} if args.control else {}
    for path in args.pairs:
        groups = defaultdict(list)
        for record in read_rows(path):
            groups[record['start']['playerCount']].append(record)
        for _, table in sorted(groups.items()):
            matched = base if table[0]['start']['seed'] in base else {}
            print(json.dumps(summarize(table, matched)))


if __name__ == '__main__':
    main()
