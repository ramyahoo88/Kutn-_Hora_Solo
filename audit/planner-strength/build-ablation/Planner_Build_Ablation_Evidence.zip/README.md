# Planner build ablation evidence

Rows and case choices list open full-turn first and dedicated build second. Each control row records the result for that seat in an all-Planner game. Each paired row includes the first different choice and its importable save when a game diverged.

[Report and commands](https://github.com/ramyahoo88/Kutn-_Hora_Solo/blob/planner-build-ablation/docs/Planner_Build_Ablation.md)
