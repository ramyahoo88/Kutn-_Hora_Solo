# Mincmistr v1.2 audit evidence

Audit target e1712d92a7b8881685c9223d266363e976f3d5e4. The Planner comparison uses v0.3.1 at 9d1dfd839234a01521ae9fb4c372da6c23351b16.

See the report for commands and the findings. The scripts run with Node 24 and Python 3.

[Audit report](https://github.com/ramyahoo88/Kutn-_Hora_Solo/blob/audit-mincmistr-v1.2/docs/Astra_Mincmistr_Audit_v1.2.md)
