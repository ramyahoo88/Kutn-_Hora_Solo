"""Produce board-cluster intervals from the audit's rotated-seat runs."""
from collections import defaultdict
from pathlib import Path
from random import Random
from statistics import mean
import json
import sys


def interval(values):
    rng = Random(20261115)
    draws = sorted(mean(rng.choices(values, k=len(values))) for _ in range(4000))
    return [draws[100], draws[3899]]


def outcome(row):
    seat = row['focus']
    other = max(vp for i, vp in enumerate(row['tot']) if i != seat)
    return (int(row['winner'] == seat), row['tot'][seat] - other)


def collect(path):
    cells = defaultdict(list)
    for line in Path(path).read_text().splitlines():
        record = json.loads(line)
        key = (record['players'], record['policy'], record['level'], record.get('deck', 'individual'))
        cells[key].append(record)
    return cells


def summarize(key, boards):
    players, policy, level, deck = key
    by_board = [[outcome(row) for row in b['rows']] for b in boards]
    rows = [row for b in boards for row in b['rows']]
    data = dict(players=players, policy=policy, level=level, deck=deck, boards=len(boards), games=len(rows))
    data['wins'] = sum(win for group in by_board for win, _ in group)
    data['shared'] = sum(row['winner'] is None and row['focus'] in row['winners'] for row in rows)
    data['win95'] = interval([mean(win for win, _ in group) for group in by_board])
    data['margin'] = mean(margin for group in by_board for _, margin in group)
    data['margin95'] = interval([mean(margin for _, margin in group) for group in by_board])
    data['interceptions'] = mean(row.get('interceptions', 0) for row in rows)
    data['paper_skips'] = mean(row['paperSkips'] for row in rows)
    return data


for filename in sys.argv[1:]:
    cells = collect(filename)
    for key, group in sorted(cells.items()):
        print(json.dumps(dict(run=Path(filename).name, **summarize(key, sorted(group, key=lambda item: item['seed'])))))
